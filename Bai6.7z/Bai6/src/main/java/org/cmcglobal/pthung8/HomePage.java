package org.cmcglobal.pthung8;

public class HomePage {
    public static void main(String[] args) {

    }
}
